# PS3 client work — not implemented yet

The server protocol is now defined in `protocol.h`. There is deliberately no fake SPRX or EBOOT in this milestone.

The next client milestone requires a lawful, user-supplied game dump/build for analysis and a confirmed console/toolchain profile. The plugin must eventually:

1. Establish the guest session over HTTP.
2. Create/join a two-player room and exchange ready state.
3. Open a UDP socket and send the `GHC1` envelope to the relay.
4. Decode the peer's slot/sequence/payload.
5. Only after the above transport works, investigate game-specific player creation, replication, damage, AI targeting, checkpoints and mission scripting.

No campaign memory offsets, player-spawn hooks, or game-script entry points have been verified. Do not install a placeholder EBOOT/SPRX; none is included.
