# Ghosts Campaign Co-op — Prototype 0.2

A research, lobby and networking prototype for a two-player co-op experiment in the original PS3 Campaign of Call of Duty: Ghosts.

## Target experience

- Maximum two players.
- Player 1 remains Logan and drives the original Campaign story flow.
- Player 2 is an additional Multiplayer-style soldier actor.
- Story NPCs such as Hesh are never replaced.
- Original Campaign missions and story progression remain intact.
- Separate PSN and Guest access are planned. Guest mode is independent of PSN; this project does not bypass PSN bans or forge PSN authentication.

## Current status

| Component | Status |
|---|---|
| Guest sessions | Implemented prototype |
| Six-character private room codes | Implemented prototype |
| Two-player room cap | Implemented prototype |
| Ready/start flow | Implemented prototype |
| UDP peer relay | Implemented prototype |
| Regional title-ID registry | Implemented; profiles are untested |
| CEX 4.93 + TU 1.16 target profile | Selected; not hardware verified |
| PS3 client plugin | Not implemented |
| Second Campaign player actor | Not proven |
| Campaign replication (AI/weapons/damage/checkpoints) | Not implemented |
| PSN identity mode | Not configured |
| PKG/EBOOT/SPRX | Not built |

## Compatibility approach

The project will not claim one universal EBOOT/SPRX for every PS3 edition. It selects a build profile by title ID, title update, firmware family and firmware version. Known regional/distribution IDs are listed in `docs/compatibility-matrix.md`.

**First target:** CEX 4.93, Ghosts Title Update 1.16. Other CEX versions, DEX and HEN require separate builds and validation. Region variants are registered, not yet tested.

## Run the prototype server

Requires Python 3.10+ and no third-party packages.

```bash
python -m server.run
```

Default endpoints:

- HTTP lobby API: `http://127.0.0.1:8080`
- UDP relay: `127.0.0.1:28991`
- Health: `GET /health`
- Compatibility registry: `GET /v1/compatibility`
- One title profile: `GET /v1/compatibility/BLUS31270`
- Install profile check: `POST /v1/compatibility/check`

Example profile check:

```json
{
  "title_id": "BLUS31270",
  "title_update": "1.16",
  "firmware_type": "CEX",
  "firmware_version": "4.93"
}
```

The result deliberately says `target_profile_not_hardware_verified`; it is not a claim that Campaign co-op works yet.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Important limitations

This is not yet a playable Campaign mod. The server can create rooms and relay opaque UDP packets, but it cannot create a second player inside Ghosts. The highest-risk unknown is whether the Campaign runtime can safely spawn and control a second actor without breaking Logan's camera, input, story scripts, NPCs or mission triggers. See `docs/feasibility.md` and `docs/compatibility-matrix.md`.
