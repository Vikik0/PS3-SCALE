"""Ghosts Campaign Co-op prototype server package."""
