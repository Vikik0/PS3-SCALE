# Required PS3 test profile

Before building a game-specific SPRX/EBOOT, record:

- Game edition: disc or digital.
- Exact title ID: e.g. BLUS31270 / BLES01945 / NPUB31301 / NPEB01832.
- Game update: target 1.16, verify in-game.
- Console environment: CFW or HEN.
- Firmware version.
- CEX or DEX environment.
- Whether the console can run an existing known-good Ghosts 1.16 plugin/EBOOT pair.
- Whether a clean, backed-up game install is available for offline testing.

## Safety and rollback

- Keep an untouched copy of the original EBOOT and game data.
- Test offline first; do not use experimental plugins in public PSN lobbies.
- Do not install an EBOOT/SPRX that is not built for the exact title ID, update and console environment.
- This repository currently contains no EBOOT, SPRX, game files or executable patch.
